// 修改时间: 近7天、近1月、近3月、近1年
export const CHANGE_TIME = "change_time";
// 修改气象菜单: 温、湿、光、雨、风
export const CHANGE_MENU = "change_menu";
// 右半边修改时间： 
export const CHANGE_TERMINAL_TIME = "change_terminal_time";
// 终端对应的名称
export const TERMINAL_NAME = "terminal_to_name";
// mouseover的终端id
export const TERMINAL_ID = "terminal_to_id";