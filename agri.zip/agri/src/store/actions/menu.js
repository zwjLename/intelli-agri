import { createAction } from "redux-actions";
import { CHANGE_MENU } from "../const";

export const changeMenu = createAction(CHANGE_MENU);
