import {createAction} from 'redux-actions'
export const current_point = createAction('current_point')